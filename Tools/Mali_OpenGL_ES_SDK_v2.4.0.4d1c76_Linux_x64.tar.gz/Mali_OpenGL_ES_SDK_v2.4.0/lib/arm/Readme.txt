These are dummy libraries for linking against at build time.
The application will require the real device libraries to run.

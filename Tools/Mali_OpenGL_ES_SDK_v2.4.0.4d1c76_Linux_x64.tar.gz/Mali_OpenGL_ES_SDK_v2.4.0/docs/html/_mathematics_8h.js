var _mathematics_8h =
[
    [ "M_PI", "_mathematics_8h.html#ae71449b1cc6e6250b91f539153a7a0d3", null ],
    [ "degreesToRadians", "_mathematics_8h.html#a683f8db3cdf4522a549aa6b237661df4", null ],
    [ "distanceBetweenPoints", "_mathematics_8h.html#a2f87bfe7b4ac0f8d13b6daeebc9c11a2", null ],
    [ "signum", "_mathematics_8h.html#afb22679b1096eb481f6581de04e49fbd", null ],
    [ "uniformRandomNumber", "_mathematics_8h.html#a1ce80d46c84adf4b66cfc0cdc352cce9", null ]
];
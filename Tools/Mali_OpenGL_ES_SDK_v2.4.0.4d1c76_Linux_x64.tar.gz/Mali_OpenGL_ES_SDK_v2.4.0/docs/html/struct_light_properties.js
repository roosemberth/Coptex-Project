var struct_light_properties =
[
    [ "direction", "struct_light_properties.html#a9fe277cff09bccad351007a0c81d5c71", null ],
    [ "position", "struct_light_properties.html#a244d4e24345df514bf5fa813bbbb2868", null ]
];
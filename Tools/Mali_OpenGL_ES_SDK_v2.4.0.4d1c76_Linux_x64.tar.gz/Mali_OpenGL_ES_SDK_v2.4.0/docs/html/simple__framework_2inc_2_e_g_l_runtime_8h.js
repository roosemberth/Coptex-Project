var simple__framework_2inc_2_e_g_l_runtime_8h =
[
    [ "EGLRuntime", "class_mali_s_d_k_1_1_e_g_l_runtime.html", "class_mali_s_d_k_1_1_e_g_l_runtime" ],
    [ "EGL_CHECK", "simple__framework_2inc_2_e_g_l_runtime_8h.html#a43f2e753de422d9710dad9e21b4e9fff", null ]
];
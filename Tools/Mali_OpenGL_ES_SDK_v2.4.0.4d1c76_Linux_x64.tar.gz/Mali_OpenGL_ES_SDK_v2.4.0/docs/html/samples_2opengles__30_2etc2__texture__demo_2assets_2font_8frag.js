var samples_2opengles__30_2etc2__texture__demo_2assets_2font_8frag =
[
    [ "main", "samples_2opengles__30_2etc2__texture__demo_2assets_2font_8frag.html#acdef7a1fd863a6d3770c1268cb06add3", null ],
    [ "color", "samples_2opengles__30_2etc2__texture__demo_2assets_2font_8frag.html#a0a3e99eab94835ffca469f09cb4a24ef", null ],
    [ "float", "samples_2opengles__30_2etc2__texture__demo_2assets_2font_8frag.html#a74fe015ec452ae5dc48201a6e992f7a1", null ],
    [ "u_s2dTexture", "samples_2opengles__30_2etc2__texture__demo_2assets_2font_8frag.html#aaee9fae7a6131eb05aca2e738797c789", null ],
    [ "v_v2TexCoord", "samples_2opengles__30_2etc2__texture__demo_2assets_2font_8frag.html#a8e16b9bea1e3e7e50c72a148f407a3e2", null ],
    [ "v_v4FontColor", "samples_2opengles__30_2etc2__texture__demo_2assets_2font_8frag.html#a32bd4b2d96749e58a3f7fcace6db4685", null ]
];
var _skybox_8cpp =
[
    [ "main", "_skybox_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "window_height", "_skybox_8cpp.html#aab3a982aa70d915d2854f223527f6a54", null ],
    [ "window_width", "_skybox_8cpp.html#a2498ca31174791206fbf178ac54dec8d", null ]
];
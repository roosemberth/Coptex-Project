var struct_image =
[
    [ "fileName", "struct_image.html#a7c31de7cbc0294f83506ae7221841ee3", null ],
    [ "internalformat", "struct_image.html#a03286b2f52abab280e659a14f66eca83", null ],
    [ "nameOfImageIneternalformat", "struct_image.html#afc908aa70d8c15ddd393aa0878414a45", null ],
    [ "textureId", "struct_image.html#a85f24b1f946ddca0015c0d7ed39eb698", null ]
];
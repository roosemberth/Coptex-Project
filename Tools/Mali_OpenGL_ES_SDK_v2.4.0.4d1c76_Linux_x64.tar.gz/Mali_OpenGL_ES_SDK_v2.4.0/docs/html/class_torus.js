var class_torus =
[
    [ "Torus", "class_torus.html#a34c45704a9715a51a8ae8838831edc91", null ],
    [ "~Torus", "class_torus.html#ae8b6a25424d9cce97b7b5a2a162938e6", null ],
    [ "draw", "class_torus.html#ab451be801d21125b75e12e402afaa1a5", null ],
    [ "initializeVertexAttribs", "class_torus.html#aeae459d72162a6197297e5574d2cdcbd", null ],
    [ "setColor", "class_torus.html#a2f52908d5dd482659ae67beff6db32f4", null ],
    [ "setProjectionMatrix", "class_torus.html#a9f3bef43e9c781ac5121b4457a40b383", null ],
    [ "setResourceDirectory", "class_torus.html#a2de0d84228a93966a2a82984d04cafcb", null ],
    [ "setupGraphics", "class_torus.html#af569b74740a9d2dfc6ce73a33a067bbe", null ],
    [ "circleRadius", "class_torus.html#acc2333207d9e476e7e9440d169abcf6a", null ],
    [ "circlesCount", "class_torus.html#a392f7f5ad2dbc2aed22052a9d0360d3d", null ],
    [ "componentsCount", "class_torus.html#a2b9e71f7b265642d967065e3daf5d8cc", null ],
    [ "pointsPerCircleCount", "class_torus.html#af0c39a3b44035f7c3ac0a299d050e3c9", null ],
    [ "programID", "class_torus.html#a626ebe7a0ee31f7de6da7dc5c53ea311", null ],
    [ "resourceDirectory", "class_torus.html#aedec15e4accc4e6376141168ec658831", null ],
    [ "torusRadius", "class_torus.html#a51974e76cf184adfaa3b5738f08706c0", null ],
    [ "torusVerticesCount", "class_torus.html#ad714a3d8a3f2a25fb12b0066a6af1ba2", null ],
    [ "vaoID", "class_torus.html#a854ca8b8051565f1eb96ba9fd806c2b6", null ],
    [ "vertexComponentsCount", "class_torus.html#ad1c7c5136189eedc18eb51f9c5cc5f48", null ]
];
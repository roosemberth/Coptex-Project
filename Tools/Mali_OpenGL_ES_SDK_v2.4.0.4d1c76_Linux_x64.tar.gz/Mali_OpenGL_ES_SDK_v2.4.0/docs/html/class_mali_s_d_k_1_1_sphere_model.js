var class_mali_s_d_k_1_1_sphere_model =
[
    [ "getPointRepresentation", "class_mali_s_d_k_1_1_sphere_model.html#a5f776b3037d90af542618498f64dd39f", null ],
    [ "getTriangleRepresentation", "class_mali_s_d_k_1_1_sphere_model.html#abfe2505360eda0b1086fc1c9266797f1", null ]
];
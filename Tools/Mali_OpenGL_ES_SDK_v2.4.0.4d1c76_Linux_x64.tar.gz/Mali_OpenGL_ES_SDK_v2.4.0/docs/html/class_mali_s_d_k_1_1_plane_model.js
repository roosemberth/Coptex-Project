var class_mali_s_d_k_1_1_plane_model =
[
    [ "getNormals", "class_mali_s_d_k_1_1_plane_model.html#a06303e836f616972caed4a19437db9ae", null ],
    [ "getTriangleRepresentation", "class_mali_s_d_k_1_1_plane_model.html#aa2e016bcce0737448e3938cfcd6d1a1c", null ],
    [ "getTriangleRepresentationUVCoordinates", "class_mali_s_d_k_1_1_plane_model.html#a21f21a47411f3087d46579ff89227d28", null ],
    [ "transform", "class_mali_s_d_k_1_1_plane_model.html#acf7d7d2718ee84aa9e90c5f2a0c3386f", null ]
];
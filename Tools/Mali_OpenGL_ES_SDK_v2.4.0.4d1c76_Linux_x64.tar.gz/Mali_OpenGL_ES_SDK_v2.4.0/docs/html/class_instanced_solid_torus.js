var class_instanced_solid_torus =
[
    [ "InstancedSolidTorus", "class_instanced_solid_torus.html#afb309733fac929dcda122af1c0c82aa3", null ],
    [ "~InstancedSolidTorus", "class_instanced_solid_torus.html#abe0ebbaa58481304277d7c47cafe7524", null ],
    [ "draw", "class_instanced_solid_torus.html#ae08fc72349bddb25c0c1cf2b65959d29", null ],
    [ "initializeControlUniformBuffers", "class_instanced_solid_torus.html#ac9a128234c0e9665a6a07ecc11156b41", null ],
    [ "initializeVertexAttribs", "class_instanced_solid_torus.html#ab5c4cf287a2f9be71b8cfac45ae4015e", null ],
    [ "setLightParameters", "class_instanced_solid_torus.html#a281501b7e580c8f08b57d306b6f180f8", null ],
    [ "controlIndicesBufferID", "class_instanced_solid_torus.html#a258b5149aee2f15e09475260c9596585", null ],
    [ "controlPointsIndicesCount", "class_instanced_solid_torus.html#ad40353e29e5c5f2153de73166ad819a9", null ],
    [ "controlPointsInPatchCount", "class_instanced_solid_torus.html#ac7e4b44c874dfc3ef1140b635c8f8dd5", null ],
    [ "controlVerticesBufferID", "class_instanced_solid_torus.html#a3b44101fd906ad7b2ae5fa1814bc1699", null ],
    [ "patchComponentsCount", "class_instanced_solid_torus.html#af12405785d02edb114acfe124ff51ce2", null ],
    [ "patchDensity", "class_instanced_solid_torus.html#a19ccbb563183ce3f282274b2834984ec", null ],
    [ "patchDimension", "class_instanced_solid_torus.html#adb2d962662a5e37303342a740f44e258", null ],
    [ "patchIndicesBufferID", "class_instanced_solid_torus.html#a56f7ca664b77d5bdc2640209e1ccc409", null ],
    [ "patchInstancesCount", "class_instanced_solid_torus.html#a68c50184ab32fdf064ea7b1d279a5d07", null ],
    [ "patchTriangleIndicesCount", "class_instanced_solid_torus.html#a5c9d386960906547907a19edb0e73b7d", null ],
    [ "patchVertexBufferID", "class_instanced_solid_torus.html#a62b6908ab61661cb89a73ca9ba7c1575", null ],
    [ "patchVerticesCount", "class_instanced_solid_torus.html#a1525e9e91ad749ae16a96f06460307bb", null ],
    [ "quadsInPatchCount", "class_instanced_solid_torus.html#a8b48732fd2996cd9f599f6bfc3eeaa8e", null ]
];
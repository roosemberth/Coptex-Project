var struct_quaternion =
[
    [ "w", "struct_quaternion.html#aa44a65ab99e36f6ab8771030eed8a7ad", null ],
    [ "x", "struct_quaternion.html#a8b80f191a3155cc0158d2b4f4d50b2cb", null ],
    [ "y", "struct_quaternion.html#a3bd3f270462944423611f44e19d2511b", null ],
    [ "z", "struct_quaternion.html#a625cb732d8ff3083e7852b86b736ab29", null ]
];
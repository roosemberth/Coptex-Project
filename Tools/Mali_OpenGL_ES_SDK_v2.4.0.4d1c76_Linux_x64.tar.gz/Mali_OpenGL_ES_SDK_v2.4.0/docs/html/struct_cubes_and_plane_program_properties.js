var struct_cubes_and_plane_program_properties =
[
    [ "colorOfGeometryLocation", "struct_cubes_and_plane_program_properties.html#a1b4e835de75e47389aefe651110ca122", null ],
    [ "isCameraPointOfViewLocation", "struct_cubes_and_plane_program_properties.html#a052267dd96f1384b25f17c72c968526b", null ],
    [ "lightDirectionLocation", "struct_cubes_and_plane_program_properties.html#aab5cad73ee7df30441e02fc6850c9802", null ],
    [ "lightPositionLocation", "struct_cubes_and_plane_program_properties.html#a5e61902f1d78d15ec09ffe9aedf7a036", null ],
    [ "lightViewMatrixLocation", "struct_cubes_and_plane_program_properties.html#a7ae918a300cdca55a809e549efc6a36b", null ],
    [ "normalsAttributeLocation", "struct_cubes_and_plane_program_properties.html#a27e37a396d367ba8dfe9adaff7c50118", null ],
    [ "positionAttributeLocation", "struct_cubes_and_plane_program_properties.html#aaf38dea9e07e63b67513882117085945", null ],
    [ "programId", "struct_cubes_and_plane_program_properties.html#a23c751719b1521521f5472a204f6cbf3", null ],
    [ "shadowMapLocation", "struct_cubes_and_plane_program_properties.html#a7a9cc0d5b999a202ee132095ab9c8d2c", null ],
    [ "shouldRenderPlaneLocation", "struct_cubes_and_plane_program_properties.html#a0a7a3011c3e9627a94a2e9667d6d42c2", null ]
];
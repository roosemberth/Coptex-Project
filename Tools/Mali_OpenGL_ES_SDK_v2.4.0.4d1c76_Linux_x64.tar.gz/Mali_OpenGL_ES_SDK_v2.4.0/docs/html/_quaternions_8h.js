var _quaternions_8h =
[
    [ "Quaternion", "struct_quaternion.html", "struct_quaternion" ],
    [ "M_PI", "_quaternions_8h.html#ae71449b1cc6e6250b91f539153a7a0d3", null ],
    [ "Quaternion", "_quaternions_8h.html#a5cd3d2a1a3d256bebeec4da81b7f4d94", null ],
    [ "construct_modelview_matrix", "_quaternions_8h.html#a1ac924a776c62ad7392aa744ef6e2501", null ],
    [ "construct_quaternion", "_quaternions_8h.html#a534eaad2220f6b7836d2c56f1d3acc3a", null ],
    [ "multiply_quaternions", "_quaternions_8h.html#a487dac8fd59dd1daa0511335c36ae7c8", null ]
];
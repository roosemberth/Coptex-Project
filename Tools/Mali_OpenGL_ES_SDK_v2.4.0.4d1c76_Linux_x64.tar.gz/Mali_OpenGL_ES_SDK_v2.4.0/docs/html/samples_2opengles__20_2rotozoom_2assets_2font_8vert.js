var samples_2opengles__20_2rotozoom_2assets_2font_8vert =
[
    [ "main", "samples_2opengles__20_2rotozoom_2assets_2font_8vert.html#acdef7a1fd863a6d3770c1268cb06add3", null ],
    [ "a_v2TexCoord", "samples_2opengles__20_2rotozoom_2assets_2font_8vert.html#a6726212798e2a5da247efe444ca78a55", null ],
    [ "a_v4FontColor", "samples_2opengles__20_2rotozoom_2assets_2font_8vert.html#ace2bc6747b24f6a6f796ac6208819d4e", null ],
    [ "a_v4Position", "samples_2opengles__20_2rotozoom_2assets_2font_8vert.html#aad7497bbca5d4d9f90e5a1503a832127", null ],
    [ "u_m4Projection", "samples_2opengles__20_2rotozoom_2assets_2font_8vert.html#a3f3e5d32d2acce089fa33fc06cc67cfe", null ],
    [ "v_v2TexCoord", "samples_2opengles__20_2rotozoom_2assets_2font_8vert.html#a3fc300d4c1d0d278ff73cdc71803a1c5", null ],
    [ "v_v4FontColor", "samples_2opengles__20_2rotozoom_2assets_2font_8vert.html#a9396cb6722d750b7b67f7a1b43e431f4", null ]
];
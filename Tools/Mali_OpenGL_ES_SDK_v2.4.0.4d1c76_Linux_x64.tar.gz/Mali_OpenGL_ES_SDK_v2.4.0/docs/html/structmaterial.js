var structmaterial =
[
    [ "ambient", "structmaterial.html#a5cd4164c60ce2fff4a3f5ba3c87a7c0a", null ],
    [ "diffuse", "structmaterial.html#a517987fa2571be9d0a1f4555ac7fa4d8", null ],
    [ "shininess", "structmaterial.html#aa3740fd7908ec5a11bbc4a4bd5b21abc", null ],
    [ "specular", "structmaterial.html#a6680ace750c12ba2a70fcb07e0ad1328", null ]
];
var struct_user_data =
[
    [ "baseColour", "struct_user_data.html#abe906bbe83e8ee0a3b0dac41b883680b", null ],
    [ "frameTime", "struct_user_data.html#a6e2c7ad037120cb28deae55d3ab1f890", null ],
    [ "gravity", "struct_user_data.html#ae5e284865e9fbc88ec54cc9b3aa6f82c", null ],
    [ "iLocColour", "struct_user_data.html#afbf1e13c677015e5a01e60d1abe89e25", null ],
    [ "iLocGravity", "struct_user_data.html#a75854fa76c5c2c81d908608710a60689", null ],
    [ "iLocMVP", "struct_user_data.html#abff8871ff9ca5f27e4a788b27c083544", null ],
    [ "iLocParticleTimes", "struct_user_data.html#a7d89b3622b7d7e3152cc98ff83c1f34a", null ],
    [ "iLocPosition", "struct_user_data.html#acea29a45f77f8d4386c6a46f21529563", null ],
    [ "iLocSampler", "struct_user_data.html#a8cd725c4a2ded36ab49d05df6d672038", null ],
    [ "iLocVelocity", "struct_user_data.html#a2a26c1dd1d791cfb3967d3b910343fff", null ],
    [ "modelViewPerspective", "struct_user_data.html#a538a67a548e33663abbe01896af7f102", null ],
    [ "particleData", "struct_user_data.html#a09a3fa5293d52e22765fa123d1fcb070", null ],
    [ "programID", "struct_user_data.html#a43ff7599ff298b69608d6b25e899d63f", null ],
    [ "textureID", "struct_user_data.html#ad7ff2b2fa909dd12efa77f7e21f2f371", null ]
];
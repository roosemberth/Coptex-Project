var class_mali_s_d_k_1_1_super_ellipsoid_model =
[
    [ "calculateNormal", "class_mali_s_d_k_1_1_super_ellipsoid_model.html#ad043f1a3a6fe0d8b524ef1c45e817593", null ],
    [ "create", "class_mali_s_d_k_1_1_super_ellipsoid_model.html#a11754ed92c438d640e4e2f9706c7431d", null ],
    [ "sample", "class_mali_s_d_k_1_1_super_ellipsoid_model.html#af64d1dbf59ae9a8f69d2fcb3a5091864", null ],
    [ "storeVertexAndNormalVectorInArray", "class_mali_s_d_k_1_1_super_ellipsoid_model.html#a0b5be4cb154188589e75887099ccbdbf", null ]
];
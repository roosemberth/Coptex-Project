var astc__textures_2assets_2shader_8frag =
[
    [ "main", "astc__textures_2assets_2shader_8frag.html#acdef7a1fd863a6d3770c1268cb06add3", null ],
    [ "cloud_texture", "astc__textures_2assets_2shader_8frag.html#a1c344900b691c57f900191b3224bc3c5", null ],
    [ "color", "astc__textures_2assets_2shader_8frag.html#a0a3e99eab94835ffca469f09cb4a24ef", null ],
    [ "daytime_texture", "astc__textures_2assets_2shader_8frag.html#a4348204cca9bdf5c29a381a9cea31ea9", null ],
    [ "float", "astc__textures_2assets_2shader_8frag.html#a74fe015ec452ae5dc48201a6e992f7a1", null ],
    [ "light", "astc__textures_2assets_2shader_8frag.html#ae3593052217b3cc2e08488849f670e4a", null ],
    [ "nighttime_texture", "astc__textures_2assets_2shader_8frag.html#a8148e7c90be18ac55067a1ab2d1fa63f", null ],
    [ "normal", "astc__textures_2assets_2shader_8frag.html#a1f159fcbc90ec160acffa23f1df377d1", null ],
    [ "tex2dcoord", "astc__textures_2assets_2shader_8frag.html#a0c197ac4836282060c52d9e9555fc84b", null ],
    [ "view", "astc__textures_2assets_2shader_8frag.html#a5cd37df6ac6fe09aa869b41a2595dfd9", null ]
];
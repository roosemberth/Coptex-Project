var struct_light_representation_program_properties =
[
    [ "positionLocation", "struct_light_representation_program_properties.html#af373973d6d12e0c0fd95dce395e2cf3b", null ],
    [ "programId", "struct_light_representation_program_properties.html#a07c02bcc1c01b8dcc0f8a8f94e9ac1df", null ]
];
var samples_2opengles__30_2skybox_2_text_8h =
[
    [ "Vec2", "class_mali_s_d_k_1_1_vec2.html", "class_mali_s_d_k_1_1_vec2" ],
    [ "Text", "class_mali_s_d_k_1_1_text.html", "class_mali_s_d_k_1_1_text" ],
    [ "Vec2", "samples_2opengles__30_2skybox_2_text_8h.html#a070b5db3523d16f9894749f1ba3939b6", null ],
    [ "get_and_check_attrib_location", "samples_2opengles__30_2skybox_2_text_8h.html#a55819c8913b8175dd2aa8b35c625d69b", null ],
    [ "get_and_check_uniform_location", "samples_2opengles__30_2skybox_2_text_8h.html#a12442d039102f33ba93918ded27d94ec", null ],
    [ "loadData", "samples_2opengles__30_2skybox_2_text_8h.html#a26034374ebba9ced8cbb90d6b947cdd8", null ]
];
var structquery =
[
    [ "attribute", "structquery.html#a5dd0e6f422b3e395e180d2e0d8a38866", null ],
    [ "meaning", "structquery.html#acc2dbfd690160b390c382ebd062cc02d", null ],
    [ "text", "structquery.html#af0ddd798f6858aacb8d0ed3fe53cd254", null ]
];
var _e_t_c_compressed_alpha_8h =
[
    [ "GLES_VERSION", "_e_t_c_compressed_alpha_8h.html#a88387fe2c4e6e89894ad5446698c2423", null ],
    [ "indices", "_e_t_c_compressed_alpha_8h.html#ab898fdb8254d8f131c3dd96ba6ff0686", null ],
    [ "textureCoordinates", "_e_t_c_compressed_alpha_8h.html#aadd4a353b19613f2fb7b23ee69ae25bc", null ],
    [ "vertices", "_e_t_c_compressed_alpha_8h.html#a204a92a9fb4329952af4ac7b3c0e1c96", null ]
];
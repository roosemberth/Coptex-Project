var samples_2opengles__30_2astc__textures_2_text_8h =
[
    [ "Text", "class_mali_s_d_k_1_1_text.html", "class_mali_s_d_k_1_1_text" ],
    [ "loadData", "samples_2opengles__30_2astc__textures_2_text_8h.html#a26034374ebba9ced8cbb90d6b947cdd8", null ]
];
var _roto_zoom_8h =
[
    [ "GLES_VERSION", "_roto_zoom_8h.html#a88387fe2c4e6e89894ad5446698c2423", null ],
    [ "quadIndices", "_roto_zoom_8h.html#a97997ab8a43c5bc0d26d9f826406b0eb", null ],
    [ "quadTextureCoordinates", "_roto_zoom_8h.html#a90105b89589f2d157b8bc98dd9a8be27", null ],
    [ "quadVertices", "_roto_zoom_8h.html#a6b090202bd5483b7d7ff38724a1af4f3", null ]
];
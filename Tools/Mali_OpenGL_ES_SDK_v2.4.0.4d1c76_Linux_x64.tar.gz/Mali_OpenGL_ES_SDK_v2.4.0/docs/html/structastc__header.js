var structastc__header =
[
    [ "blockdim_x", "structastc__header.html#a0b1966d853ab9281f611da7b9ecdb2f2", null ],
    [ "blockdim_y", "structastc__header.html#a58131efe7af3a154489c98698d303516", null ],
    [ "blockdim_z", "structastc__header.html#a3a0ba405280510e95f877a1d479269a2", null ],
    [ "magic", "structastc__header.html#a4cb93c3e59593d798729de11bc5cba55", null ],
    [ "xsize", "structastc__header.html#a6a0c11bae17701a46151ddaf9a493591", null ],
    [ "ysize", "structastc__header.html#a2954ee20b86e975ae087d20063d26f46", null ],
    [ "zsize", "structastc__header.html#aa36155620d9f34dcf33c3b7a72dddf05", null ]
];
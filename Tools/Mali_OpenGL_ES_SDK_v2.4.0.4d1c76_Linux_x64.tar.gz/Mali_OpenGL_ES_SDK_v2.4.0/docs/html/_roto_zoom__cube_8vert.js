var _roto_zoom__cube_8vert =
[
    [ "main", "_roto_zoom__cube_8vert.html#acdef7a1fd863a6d3770c1268cb06add3", null ],
    [ "a_v2TexCoord", "_roto_zoom__cube_8vert.html#a6726212798e2a5da247efe444ca78a55", null ],
    [ "a_v4Position", "_roto_zoom__cube_8vert.html#aad7497bbca5d4d9f90e5a1503a832127", null ],
    [ "u_m4Texture", "_roto_zoom__cube_8vert.html#ac78d7ddee73bc808c914654fbad08362", null ],
    [ "v_v2TexCoord", "_roto_zoom__cube_8vert.html#a3fc300d4c1d0d278ff73cdc71803a1c5", null ]
];
function WriteLeftMenu(divID, aID, divClassName, aClassName)
{
document.write("<div id=\"divID6826\" class=\"headerLeftMenuInActive\"><a id=\"aID6826\" href=\"#\" OnMouseOver=\"link('_dir','basicmi_twimi_eeprommi_project0',this)\" class=\"leftMenuLinkHeadInActive\">basic-twi-eeprom-project</a></div>\n");
document.write("<div class=\"paragraphLeftMenu\">Units</div>\n");
document.write("<div id=\"divID6951\" class=\"leftMenuInActive\"><a id=\"aID6951\" href=\"#\" OnMouseOver=\"link('_unit','main_c0',this)\" class=\"leftMenuLinkInActive\">main.c</a></div>\n");
if(divID != "" && aID != "")
{
document.getElementById(divID).className = divClassName;
document.getElementById(aID).className = aClassName;
}
}

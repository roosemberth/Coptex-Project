function WriteLeftMenu(divID, aID, divClassName, aClassName)
{
document.write("<div id=\"divID6823\" class=\"headerLeftMenuInActive\"><a id=\"aID6823\" href=\"#\" OnMouseOver=\"link('_dir','basicmi_rttmi_project0',this)\" class=\"leftMenuLinkHeadInActive\">basic-rtt-project</a></div>\n");
document.write("<div class=\"paragraphLeftMenu\">Units</div>\n");
document.write("<div id=\"divID6948\" class=\"leftMenuInActive\"><a id=\"aID6948\" href=\"#\" OnMouseOver=\"link('_unit','main_c0',this)\" class=\"leftMenuLinkInActive\">main.c</a></div>\n");
if(divID != "" && aID != "")
{
document.getElementById(divID).className = divClassName;
document.getElementById(aID).className = aClassName;
}
}

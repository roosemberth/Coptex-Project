function WriteLeftMenu(divID, aID, divClassName, aClassName)
{
document.write("<div id=\"divID6836\" class=\"headerLeftMenuInActive\"><a id=\"aID6836\" href=\"#\" OnMouseOver=\"link('_dir','usbmi_devicemi_hidmi_mousemi_project0',this)\" class=\"leftMenuLinkHeadInActive\">usb-device-hid-mouse-project</a></div>\n");
document.write("<div class=\"paragraphLeftMenu\">Units</div>\n");
document.write("<div id=\"divID6961\" class=\"leftMenuInActive\"><a id=\"aID6961\" href=\"#\" OnMouseOver=\"link('_unit','main_c0',this)\" class=\"leftMenuLinkInActive\">main.c</a></div>\n");
if(divID != "" && aID != "")
{
document.getElementById(divID).className = divClassName;
document.getElementById(aID).className = aClassName;
}
}
